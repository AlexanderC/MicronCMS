${include _header.md}
# Sample page
${include _footer.md}