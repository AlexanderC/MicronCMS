${include _header.md}
## It works!
#### For more details visit [GitHub project page](https://github.com/AlexanderC/MicronCMS "GitHub page")
${include _footer.md}