<?php
namespace MicronCMS { interface CompilableInterface { public static function preCompile(\ReflectionClass $static); public static function postCompile(& $generatedCode); public static function compileDependencies(); } abstract class AbstractCompilable implements CompilableInterface { public static function preCompile(\ReflectionClass $static) { } public static function postCompile(& $generatedCode) { } public static function compileDependencies() { return []; } } class Application extends AbstractCompilable { protected $contentDirectory; protected $resolver; protected $cache = false; public function __construct($contentDirectory) { $this->contentDirectory = realpath($contentDirectory); if (empty($this->contentDirectory)) { throw new \MicronCMS\Exception\ApplicationException("Missing content directory"); } $this->resolver = new \MicronCMS\FileSystem\PathResolver($this->contentDirectory); } public function getResolver() { return $this->resolver; } public function isCache() { return $this->cache; } public function setCache($cache) { $this->cache = $cache; return $this; } public function createErrorResponse() { $templateFile = $this->resolver->resolve('_500'); if ($templateFile) { $template = \MicronCMS\Templating\AbstractTemplate::create($templateFile); if ($this->cache) { $template->cache(); } return new \MicronCMS\HttpKernel\Response($template->compile(), \MicronCMS\HttpKernel\Response::ERROR); } return new \MicronCMS\HttpKernel\Response('Internal server error', \MicronCMS\HttpKernel\Response::ERROR); } public function createNotFoundResponse() { $templateFile = $this->resolver->resolve('_404'); if ($templateFile) { $template = \MicronCMS\Templating\AbstractTemplate::create($templateFile); if ($this->cache) { $template->cache(); } return new \MicronCMS\HttpKernel\Response($template->compile(), \MicronCMS\HttpKernel\Response::NOT_FOUND); } return new \MicronCMS\HttpKernel\Response('Page not found', \MicronCMS\HttpKernel\Response::NOT_FOUND); } public function dispatch(\MicronCMS\HttpKernel\Request $request = null) { $request = $request ?: \MicronCMS\HttpKernel\Request::createFromGlobals(); $path = $request->getPath(); try { $templateFile = $this->resolver->resolve($path); if (null === $templateFile) { $response = $this->createNotFoundResponse(); } else { $template = \MicronCMS\Templating\AbstractTemplate::create($templateFile); $compiledContent = $template->compile(); if ($this->cache) { $template->cache(); } $response = new \MicronCMS\HttpKernel\Response($compiledContent, \MicronCMS\HttpKernel\Response::SUCCESS); } } catch (\MicronCMS\Exception\Exception $e) { $response = $this->createErrorResponse(); } return $response; } public function getContentDirectory() { return $this->contentDirectory; } } } namespace MicronCMS\FileSystem { class RecursiveWalker extends \MicronCMS\AbstractCompilable implements \IteratorAggregate { protected $path; protected $filterRegexp; public function __construct($path, $filterRegexp = null) { $this->path = realpath($path); if (empty($this->path)) { throw new \MicronCMS\FileSystem\Exception\Exception("Missing path to walk through"); } $this->filterRegexp = $filterRegexp; } public function getIterator() { $rdi = new \RecursiveDirectoryIterator($this->path, \RecursiveDirectoryIterator::SKIP_DOTS); $rii = new \RecursiveIteratorIterator($rdi); $rii->rewind(); while ($rii->valid()) { if (empty($this->filterRegexp) || preg_match($this->filterRegexp, (string)$rii->current())) { yield $rii->current(); } $rii->next(); } } } class PathResolver extends \MicronCMS\AbstractCompilable { const INDEX = '_index'; protected $baseDirectory; protected $allowedExtensions = ['md', 'html', 'txt', 'json']; public function __construct($baseDirectory) { $this->baseDirectory = realpath($baseDirectory); if (empty($this->baseDirectory)) { throw new \MicronCMS\FileSystem\Exception\MissingPathException("Missing base directory"); } } public function getBaseDirectory() { return $this->baseDirectory; } public function getAllowedExtensions() { return $this->allowedExtensions; } public function resolve($path) { $path = ltrim($path, '/'); $path = empty($path) ? self::INDEX : $path; $baseFilePath = sprintf('%s/%s', $this->baseDirectory, $path); $regexp = sprintf( '/^%s\.(%s)$/ui', preg_quote($baseFilePath, '/'), implode('|', $this->allowedExtensions) ); $nativeFile = sprintf('%s.%s', $baseFilePath, \MicronCMS\Templating\AbstractTemplate::NATIVE_EXTENSION); if (is_file($nativeFile)) { return new \SplFileInfo($nativeFile); } $walker = new RecursiveWalker($this->baseDirectory, $regexp); return $walker->getIterator()->current() ?: null; } } } namespace MicronCMS\Exception { class Exception extends \RuntimeException { } class ApplicationException extends Exception { } } namespace MicronCMS\FileSystem\Exception { class Exception extends \MicronCMS\Exception\Exception { } class MissingPathException extends Exception { } } namespace MicronCMS\HttpKernel { class Request extends \MicronCMS\AbstractCompilable { protected $path; protected $data; public function __construct($path, array $data) { $this->path = sprintf('/%s', trim($path, '/')); $this->data = $data; } public function getPath() { return $this->path; } public function getData() { return $this->data; } public function set($name, $value) { $this->data[$name] = $value; return $this; } public function has($name) { return isset($this->data[$name]); } public function get($name, $default = null) { return $this->has($name) ? $this->data[$name] : $default; } public static function createFromGlobals() { return new static( $_SERVER['REQUEST_URI'], array_merge($_GET, $_POST) ); } } class Response extends \MicronCMS\AbstractCompilable { const NO_CONTENT = 204; const SUCCESS = 200; const NOT_FOUND = 404; const ERROR = 500; public $httpCode; public $content; public function __construct($content, $httpCode = self::SUCCESS) { $this->httpCode = $httpCode; $this->content = $content; } public function getHttpCode() { return $this->httpCode; } public function getContent() { return $this->content; } public function send() { if (headers_sent()) { throw new \MicronCMS\Exception\ApplicationException("Headers already sent"); } @ob_end_clean(); header('Content-Type: text/html; charset=UTF-8'); header('Cache-Control: private; max-age=0'); http_response_code($this->httpCode); @ob_end_flush(); echo $this->content; @ob_end_flush(); } } } namespace MicronCMS\Templating { abstract class AbstractTemplate extends \MicronCMS\AbstractCompilable { const NATIVE_EXTENSION = 'micron'; protected $filePath; public function __construct($filePath) { $this->filePath = $filePath; } public function getFilePath() { return $this->filePath; } public function cache() { if (static::class !== NativeTemplate::class) { $cacheFile = preg_replace( '/\.[^\.]+$/ui', sprintf('.%s', static::NATIVE_EXTENSION), $this->filePath ); if (!file_put_contents($cacheFile, $this->compile(), LOCK_EX)) { throw new \MicronCMS\Templating\Exception\CachingFailedException("Unable to create cache file"); } } } abstract public function compile(); public static function create(\SplFileInfo $file) { $extension = $file->getExtension(); if ($extension === self::NATIVE_EXTENSION) { return new NativeTemplate((string)$file); } $templateClass = sprintf('%s\\%sTemplate', __NAMESPACE__, ucfirst($extension)); if (!class_exists($templateClass)) { throw new \MicronCMS\Templating\Exception\MissingTemplateException(sprintf( "Missing template class for '%s'", $extension )); } return new $templateClass((string)$file); } } class NativeTemplate extends AbstractTemplate { public function compile() { $content = file_get_contents($this->filePath); if (false === $content) { throw new \MicronCMS\Templating\Exception\MissingTemplateException("Unable to read template file"); } $preProcessor = new PreProcessor(); $preProcessor->process($content, $this->filePath); return $content; } } class HtmlTemplate extends NativeTemplate { } class JsonTemplate extends NativeTemplate { public function compile() { $json = parent::compile(); if (false === ($content = @json_decode(trim($json)))) { throw new \MicronCMS\Templating\Exception\InvalidTemplateException("Invalid json string"); } return nl2br(str_replace(' ', '&nbsp;', json_encode($content, JSON_PRETTY_PRINT))); } } class MdTemplate extends NativeTemplate { public function compile() { $markdown = parent::compile(); $html = \Michelf\MarkdownExtra::defaultTransform($markdown); return $html; } public static function compileDependencies() { return [ \Michelf\MarkdownExtra::class ]; } } class PreProcessor extends \MicronCMS\AbstractCompilable { const T_INCLUDE = 0x001; const T_INCLUDE_REGEXP = '/(\${\s*include\s+(?P<statement>[^\s]+)\s*})/ui'; protected $parseMap = [ self::T_INCLUDE => self::T_INCLUDE_REGEXP ]; public function process(& $content, $sourceFile) { foreach ($this->parseMap as $token => $regexp) { $content = preg_replace_callback($regexp, function ($matches) use ($token, $sourceFile) { $statement = $matches['statement']; return $this->processStatement($token, $statement, $sourceFile); }, $content); } } protected function processStatement($token, $statement, $sourceFile) { switch ($token) { case self::T_INCLUDE: $basePath = dirname($sourceFile); $templateRelativePath = ltrim($statement, '/'); $templatePath = sprintf('%s/%s', $basePath, $templateRelativePath); if (!is_file($templatePath)) { throw new \MicronCMS\Templating\Exception\PreProcessingFailedException("Unable to find included template"); } $template = AbstractTemplate::create(new \SplFileInfo($templatePath)); return $template->compile(); break; } return null; } } class TxtTemplate extends NativeTemplate { public function compile() { $text = parent::compile(); return nl2br(str_replace(' ', '&nbsp;', $text)); } } } namespace MicronCMS\Templating\Exception { class Exception extends \MicronCMS\Exception\Exception { } class CachingFailedException extends Exception { } class InvalidTemplateException extends Exception { } class MissingTemplateException extends Exception { } class PreProcessingFailedException extends InvalidTemplateException { } } namespace Michelf { interface MarkdownInterface { public static function defaultTransform($text); public function transform($text); } class Markdown implements MarkdownInterface { const MARKDOWNLIB_VERSION = "1.5.0"; public static function defaultTransform($text) { $parser_class = \get_called_class(); static $parser_list; $parser =& $parser_list[$parser_class]; if (!$parser) { $parser = new $parser_class; } return $parser->transform($text); } public $empty_element_suffix = " />"; public $tab_width = 4; public $no_markup = false; public $no_entities = false; public $predef_urls = array(); public $predef_titles = array(); public $url_filter_func = null; public $header_id_func = null; public $enhanced_ordered_list = false; protected $nested_brackets_depth = 6; protected $nested_brackets_re; protected $nested_url_parenthesis_depth = 4; protected $nested_url_parenthesis_re; protected $escape_chars = '\`*_{}[]()>#+-.!'; protected $escape_chars_re; public function __construct() { $this->_initDetab(); $this->prepareItalicsAndBold(); $this->nested_brackets_re = str_repeat('(?>[^\[\]]+|\[', $this->nested_brackets_depth) . str_repeat('\])*', $this->nested_brackets_depth); $this->nested_url_parenthesis_re = str_repeat('(?>[^()\s]+|\(', $this->nested_url_parenthesis_depth) . str_repeat('(?>\)))*', $this->nested_url_parenthesis_depth); $this->escape_chars_re = '[' . preg_quote($this->escape_chars) . ']'; asort($this->document_gamut); asort($this->block_gamut); asort($this->span_gamut); } protected $urls = array(); protected $titles = array(); protected $html_hashes = array(); protected $in_anchor = false; protected function setup() { $this->urls = $this->predef_urls; $this->titles = $this->predef_titles; $this->html_hashes = array(); $this->in_anchor = false; } protected function teardown() { $this->urls = array(); $this->titles = array(); $this->html_hashes = array(); } public function transform($text) { $this->setup(); $text = preg_replace('{^\xEF\xBB\xBF|\x1A}', '', $text); $text = preg_replace('{\r\n?}', "\n", $text); $text .= "\n\n"; $text = $this->detab($text); $text = $this->hashHTMLBlocks($text); $text = preg_replace('/^[ ]+$/m', '', $text); foreach ($this->document_gamut as $method => $priority) { $text = $this->$method($text); } $this->teardown(); return $text . "\n"; } protected $document_gamut = array( "stripLinkDefinitions" => 20, "runBasicBlockGamut" => 30, ); protected function stripLinkDefinitions($text) { $less_than_tab = $this->tab_width - 1; $text = preg_replace_callback('{
    							^[ ]{0,' . $less_than_tab . '}\[(.+)\][ ]?:	# id = $1
    							  [ ]*
    							  \n?				# maybe *one* newline
    							  [ ]*
    							(?:
    							  <(.+?)>			# url = $2
    							|
    							  (\S+?)			# url = $3
    							)
    							  [ ]*
    							  \n?				# maybe one newline
    							  [ ]*
    							(?:
    								(?<=\s)			# lookbehind for whitespace
    								["(]
    								(.*?)			# title = $4
    								[")]
    								[ ]*
    							)?	# title is optional
    							(?:\n+|\Z)
    			}xm', array($this, '_stripLinkDefinitions_callback'), $text); return $text; } protected function _stripLinkDefinitions_callback($matches) { $link_id = strtolower($matches[1]); $url = $matches[2] == '' ? $matches[3] : $matches[2]; $this->urls[$link_id] = $url; $this->titles[$link_id] =& $matches[4]; return ''; } protected function hashHTMLBlocks($text) { if ($this->no_markup) { return $text; } $less_than_tab = $this->tab_width - 1; $block_tags_a_re = 'ins|del'; $block_tags_b_re = 'p|div|h[1-6]|blockquote|pre|table|dl|ol|ul|address|' . 'script|noscript|style|form|fieldset|iframe|math|svg|' . 'article|section|nav|aside|hgroup|header|footer|' . 'figure'; $nested_tags_level = 4; $attr = '
    			(?>				# optional tag attributes
    			  \s			# starts with whitespace
    			  (?>
    				[^>"/]+		# text outside quotes
    			  |
    				/+(?!>)		# slash not followed by ">"
    			  |
    				"[^"]*"		# text inside double quotes (tolerate ">")
    			  |
    				\'[^\']*\'	# text inside single quotes (tolerate ">")
    			  )*
    			)?	
    			'; $content = str_repeat('
    				(?>
    				  [^<]+			# content without tag
    				|
    				  <\2			# nested opening tag
    					' . $attr . '	# attributes
    					(?>
    					  />
    					|
    					  >', $nested_tags_level) . '.*?' . str_repeat('
    					  </\2\s*>	# closing nested tag
    					)
    				  |				
    					<(?!/\2\s*>	# other tags with a different name
    				  )
    				)*', $nested_tags_level); $content2 = str_replace('\2', '\3', $content); $text = preg_replace_callback('{(?>
    			(?>
    				(?<=\n)			# Starting on its own line
    				|				# or
    				\A\n?			# the at beginning of the doc
    			)
    			(						# save in $1
    
    			  # Match from `\n<tag>` to `</tag>\n`, handling nested tags 
    			  # in between.
    					
    						[ ]{0,' . $less_than_tab . '}
    						<(' . $block_tags_b_re . ')# start tag = $2
    						' . $attr . '>			# attributes followed by > and \n
    						' . $content . '		# content, support nesting
    						</\2>				# the matching end tag
    						[ ]*				# trailing spaces/tabs
    						(?=\n+|\Z)	# followed by a newline or end of document
    
    			| # Special version for tags of group a.
    
    						[ ]{0,' . $less_than_tab . '}
    						<(' . $block_tags_a_re . ')# start tag = $3
    						' . $attr . '>[ ]*\n	# attributes followed by >
    						' . $content2 . '		# content, support nesting
    						</\3>				# the matching end tag
    						[ ]*				# trailing spaces/tabs
    						(?=\n+|\Z)	# followed by a newline or end of document
    					
    			| # Special case just for <hr />. It was easier to make a special 
    			  # case than to make the other regex more complicated.
    			
    						[ ]{0,' . $less_than_tab . '}
    						<(hr)				# start tag = $2
    						' . $attr . '			# attributes
    						/?>					# the matching end tag
    						[ ]*
    						(?=\n{2,}|\Z)		# followed by a blank line or end of document
    			
    			| # Special case for standalone HTML comments:
    			
    					[ ]{0,' . $less_than_tab . '}
    					(?s:
    						<!-- .*? -->
    					)
    					[ ]*
    					(?=\n{2,}|\Z)		# followed by a blank line or end of document
    			
    			| # PHP and ASP-style processor instructions (<? and <%)
    			
    					[ ]{0,' . $less_than_tab . '}
    					(?s:
    						<([?%])			# $2
    						.*?
    						\2>
    					)
    					[ ]*
    					(?=\n{2,}|\Z)		# followed by a blank line or end of document
    					
    			)
    			)}Sxmi', array($this, '_hashHTMLBlocks_callback'), $text); return $text; } protected function _hashHTMLBlocks_callback($matches) { $text = $matches[1]; $key = $this->hashBlock($text); return "\n\n$key\n\n"; } protected function hashPart($text, $boundary = 'X') { $text = $this->unhash($text); static $i = 0; $key = "$boundary\x1A" . ++$i . $boundary; $this->html_hashes[$key] = $text; return $key; } protected function hashBlock($text) { return $this->hashPart($text, 'B'); } protected $block_gamut = array( "doHeaders" => 10, "doHorizontalRules" => 20, "doLists" => 40, "doCodeBlocks" => 50, "doBlockQuotes" => 60, ); protected function runBlockGamut($text) { $text = $this->hashHTMLBlocks($text); return $this->runBasicBlockGamut($text); } protected function runBasicBlockGamut($text) { foreach ($this->block_gamut as $method => $priority) { $text = $this->$method($text); } $text = $this->formParagraphs($text); return $text; } protected function doHorizontalRules($text) { return preg_replace( '{
    				^[ ]{0,3}	# Leading space
    				([-*_])		# $1: First marker
    				(?>			# Repeated marker group
    					[ ]{0,2}	# Zero, one, or two spaces.
    					\1			# Marker character
    				){2,}		# Group repeated at least twice
    				[ ]*		# Tailing spaces
    				$			# End of line.
    			}mx', "\n" . $this->hashBlock("<hr$this->empty_element_suffix") . "\n", $text); } protected $span_gamut = array( "parseSpan" => -30, "doImages" => 10, "doAnchors" => 20, "doAutoLinks" => 30, "encodeAmpsAndAngles" => 40, "doItalicsAndBold" => 50, "doHardBreaks" => 60, ); protected function runSpanGamut($text) { foreach ($this->span_gamut as $method => $priority) { $text = $this->$method($text); } return $text; } protected function doHardBreaks($text) { return preg_replace_callback('/ {2,}\n/', array($this, '_doHardBreaks_callback'), $text); } protected function _doHardBreaks_callback($matches) { return $this->hashPart("<br$this->empty_element_suffix\n"); } protected function doAnchors($text) { if ($this->in_anchor) { return $text; } $this->in_anchor = true; $text = preg_replace_callback('{
    			(					# wrap whole match in $1
    			  \[
    				(' . $this->nested_brackets_re . ')	# link text = $2
    			  \]
    
    			  [ ]?				# one optional space
    			  (?:\n[ ]*)?		# one optional newline followed by spaces
    
    			  \[
    				(.*?)		# id = $3
    			  \]
    			)
    			}xs', array($this, '_doAnchors_reference_callback'), $text); $text = preg_replace_callback('{
    			(				# wrap whole match in $1
    			  \[
    				(' . $this->nested_brackets_re . ')	# link text = $2
    			  \]
    			  \(			# literal paren
    				[ \n]*
    				(?:
    					<(.+?)>	# href = $3
    				|
    					(' . $this->nested_url_parenthesis_re . ')	# href = $4
    				)
    				[ \n]*
    				(			# $5
    				  ([\'"])	# quote char = $6
    				  (.*?)		# Title = $7
    				  \6		# matching quote
    				  [ \n]*	# ignore any spaces/tabs between closing quote and )
    				)?			# title is optional
    			  \)
    			)
    			}xs', array($this, '_doAnchors_inline_callback'), $text); $text = preg_replace_callback('{
    			(					# wrap whole match in $1
    			  \[
    				([^\[\]]+)		# link text = $2; can\'t contain [ or ]
    			  \]
    			)
    			}xs', array($this, '_doAnchors_reference_callback'), $text); $this->in_anchor = false; return $text; } protected function _doAnchors_reference_callback($matches) { $whole_match = $matches[1]; $link_text = $matches[2]; $link_id =& $matches[3]; if ($link_id == "") { $link_id = $link_text; } $link_id = strtolower($link_id); $link_id = preg_replace('{[ ]?\n}', ' ', $link_id); if (isset($this->urls[$link_id])) { $url = $this->urls[$link_id]; $url = $this->encodeURLAttribute($url); $result = "<a href=\"$url\""; if (isset($this->titles[$link_id])) { $title = $this->titles[$link_id]; $title = $this->encodeAttribute($title); $result .= " title=\"$title\""; } $link_text = $this->runSpanGamut($link_text); $result .= ">$link_text</a>"; $result = $this->hashPart($result); } else { $result = $whole_match; } return $result; } protected function _doAnchors_inline_callback($matches) { $whole_match = $matches[1]; $link_text = $this->runSpanGamut($matches[2]); $url = $matches[3] == '' ? $matches[4] : $matches[3]; $title =& $matches[7]; $unhashed = $this->unhash($url); if ($unhashed != $url) { $url = preg_replace('/^<(.*)>$/', '\1', $unhashed); } $url = $this->encodeURLAttribute($url); $result = "<a href=\"$url\""; if (isset($title)) { $title = $this->encodeAttribute($title); $result .= " title=\"$title\""; } $link_text = $this->runSpanGamut($link_text); $result .= ">$link_text</a>"; return $this->hashPart($result); } protected function doImages($text) { $text = preg_replace_callback('{
    			(				# wrap whole match in $1
    			  !\[
    				(' . $this->nested_brackets_re . ')		# alt text = $2
    			  \]
    
    			  [ ]?				# one optional space
    			  (?:\n[ ]*)?		# one optional newline followed by spaces
    
    			  \[
    				(.*?)		# id = $3
    			  \]
    
    			)
    			}xs', array($this, '_doImages_reference_callback'), $text); $text = preg_replace_callback('{
    			(				# wrap whole match in $1
    			  !\[
    				(' . $this->nested_brackets_re . ')		# alt text = $2
    			  \]
    			  \s?			# One optional whitespace character
    			  \(			# literal paren
    				[ \n]*
    				(?:
    					<(\S*)>	# src url = $3
    				|
    					(' . $this->nested_url_parenthesis_re . ')	# src url = $4
    				)
    				[ \n]*
    				(			# $5
    				  ([\'"])	# quote char = $6
    				  (.*?)		# title = $7
    				  \6		# matching quote
    				  [ \n]*
    				)?			# title is optional
    			  \)
    			)
    			}xs', array($this, '_doImages_inline_callback'), $text); return $text; } protected function _doImages_reference_callback($matches) { $whole_match = $matches[1]; $alt_text = $matches[2]; $link_id = strtolower($matches[3]); if ($link_id == "") { $link_id = strtolower($alt_text); } $alt_text = $this->encodeAttribute($alt_text); if (isset($this->urls[$link_id])) { $url = $this->encodeURLAttribute($this->urls[$link_id]); $result = "<img src=\"$url\" alt=\"$alt_text\""; if (isset($this->titles[$link_id])) { $title = $this->titles[$link_id]; $title = $this->encodeAttribute($title); $result .= " title=\"$title\""; } $result .= $this->empty_element_suffix; $result = $this->hashPart($result); } else { $result = $whole_match; } return $result; } protected function _doImages_inline_callback($matches) { $whole_match = $matches[1]; $alt_text = $matches[2]; $url = $matches[3] == '' ? $matches[4] : $matches[3]; $title =& $matches[7]; $alt_text = $this->encodeAttribute($alt_text); $url = $this->encodeURLAttribute($url); $result = "<img src=\"$url\" alt=\"$alt_text\""; if (isset($title)) { $title = $this->encodeAttribute($title); $result .= " title=\"$title\""; } $result .= $this->empty_element_suffix; return $this->hashPart($result); } protected function doHeaders($text) { $text = preg_replace_callback('{ ^(.+?)[ ]*\n(=+|-+)[ ]*\n+ }mx', array($this, '_doHeaders_callback_setext'), $text); $text = preg_replace_callback('{
    				^(\#{1,6})	# $1 = string of #\'s
    				[ ]*
    				(.+?)		# $2 = Header text
    				[ ]*
    				\#*			# optional closing #\'s (not counted)
    				\n+
    			}xm', array($this, '_doHeaders_callback_atx'), $text); return $text; } protected function _doHeaders_callback_setext($matches) { if ($matches[2] == '-' && preg_match('{^-(?: |$)}', $matches[1])) { return $matches[0]; } $level = $matches[2]{0} == '=' ? 1 : 2; $idAtt = $this->_generateIdFromHeaderValue($matches[1]); $block = "<h$level$idAtt>" . $this->runSpanGamut($matches[1]) . "</h$level>"; return "\n" . $this->hashBlock($block) . "\n\n"; } protected function _doHeaders_callback_atx($matches) { $idAtt = $this->_generateIdFromHeaderValue($matches[2]); $level = strlen($matches[1]); $block = "<h$level$idAtt>" . $this->runSpanGamut($matches[2]) . "</h$level>"; return "\n" . $this->hashBlock($block) . "\n\n"; } protected function _generateIdFromHeaderValue($headerValue) { if (!is_callable($this->header_id_func)) { return ""; } $idValue = call_user_func($this->header_id_func, $headerValue); if (!$idValue) { return ""; } return ' id="' . $this->encodeAttribute($idValue) . '"'; } protected function doLists($text) { $less_than_tab = $this->tab_width - 1; $marker_ul_re = '[*+-]'; $marker_ol_re = '\d+[\.]'; $markers_relist = array( $marker_ul_re => $marker_ol_re, $marker_ol_re => $marker_ul_re, ); foreach ($markers_relist as $marker_re => $other_marker_re) { $whole_list_re = '
    				(								# $1 = whole list
    				  (								# $2
    					([ ]{0,' . $less_than_tab . '})	# $3 = number of spaces
    					(' . $marker_re . ')			# $4 = first list item marker
    					[ ]+
    				  )
    				  (?s:.+?)
    				  (								# $5
    					  \z
    					|
    					  \n{2,}
    					  (?=\S)
    					  (?!						# Negative lookahead for another list item marker
    						[ ]*
    						' . $marker_re . '[ ]+
    					  )
    					|
    					  (?=						# Lookahead for another kind of list
    					    \n
    						\3						# Must have the same indentation
    						' . $other_marker_re . '[ ]+
    					  )
    				  )
    				)
    			'; if ($this->list_level) { $text = preg_replace_callback('{
    						^
    						' . $whole_list_re . '
    					}mx', array($this, '_doLists_callback'), $text); } else { $text = preg_replace_callback('{
    						(?:(?<=\n)\n|\A\n?) # Must eat the newline
    						' . $whole_list_re . '
    					}mx', array($this, '_doLists_callback'), $text); } } return $text; } protected function _doLists_callback($matches) { $marker_ul_re = '[*+-]'; $marker_ol_re = '\d+[\.]'; $marker_any_re = "(?:$marker_ul_re|$marker_ol_re)"; $marker_ol_start_re = '[0-9]+'; $list = $matches[1]; $list_type = preg_match("/$marker_ul_re/", $matches[4]) ? "ul" : "ol"; $marker_any_re = ($list_type == "ul" ? $marker_ul_re : $marker_ol_re); $list .= "\n"; $result = $this->processListItems($list, $marker_any_re); $ol_start = 1; if ($this->enhanced_ordered_list) { if ($list_type == 'ol') { $ol_start_array = array(); $ol_start_check = preg_match("/$marker_ol_start_re/", $matches[4], $ol_start_array); if ($ol_start_check) { $ol_start = $ol_start_array[0]; } } } if ($ol_start > 1 && $list_type == 'ol') { $result = $this->hashBlock("<$list_type start=\"$ol_start\">\n" . $result . "</$list_type>"); } else { $result = $this->hashBlock("<$list_type>\n" . $result . "</$list_type>"); } return "\n" . $result . "\n\n"; } protected $list_level = 0; protected function processListItems($list_str, $marker_any_re) { $this->list_level++; $list_str = preg_replace("/\n{2,}\\z/", "\n", $list_str); $list_str = preg_replace_callback('{
    			(\n)?							# leading line = $1
    			(^[ ]*)							# leading whitespace = $2
    			(' . $marker_any_re . '				# list marker and space = $3
    				(?:[ ]+|(?=\n))	# space only required if item is not empty
    			)
    			((?s:.*?))						# list item text   = $4
    			(?:(\n+(?=\n))|\n)				# tailing blank line = $5
    			(?= \n* (\z | \2 (' . $marker_any_re . ') (?:[ ]+|(?=\n))))
    			}xm', array($this, '_processListItems_callback'), $list_str); $this->list_level--; return $list_str; } protected function _processListItems_callback($matches) { $item = $matches[4]; $leading_line =& $matches[1]; $leading_space =& $matches[2]; $marker_space = $matches[3]; $tailing_blank_line =& $matches[5]; if ($leading_line || $tailing_blank_line || preg_match('/\n{2,}/', $item) ) { $item = $leading_space . str_repeat(' ', strlen($marker_space)) . $item; $item = $this->runBlockGamut($this->outdent($item) . "\n"); } else { $item = $this->doLists($this->outdent($item)); $item = preg_replace('/\n+$/', '', $item); $item = $this->runSpanGamut($item); } return "<li>" . $item . "</li>\n"; } protected function doCodeBlocks($text) { $text = preg_replace_callback('{
    				(?:\n\n|\A\n?)
    				(	            # $1 = the code block -- one or more lines, starting with a space/tab
    				  (?>
    					[ ]{' . $this->tab_width . '}  # Lines must start with a tab or a tab-width of spaces
    					.*\n+
    				  )+
    				)
    				((?=^[ ]{0,' . $this->tab_width . '}\S)|\Z)	# Lookahead for non-space at line-start, or end of doc
    			}xm', array($this, '_doCodeBlocks_callback'), $text); return $text; } protected function _doCodeBlocks_callback($matches) { $codeblock = $matches[1]; $codeblock = $this->outdent($codeblock); $codeblock = htmlspecialchars($codeblock, ENT_NOQUOTES); $codeblock = preg_replace('/\A\n+|\n+\z/', '', $codeblock); $codeblock = "<pre><code>$codeblock\n</code></pre>"; return "\n\n" . $this->hashBlock($codeblock) . "\n\n"; } protected function makeCodeSpan($code) { $code = htmlspecialchars(trim($code), ENT_NOQUOTES); return $this->hashPart("<code>$code</code>"); } protected $em_relist = array( '' => '(?:(?<!\*)\*(?!\*)|(?<!_)_(?!_))(?![\.,:;]?\s)', '*' => '(?<![\s*])\*(?!\*)', '_' => '(?<![\s_])_(?!_)', ); protected $strong_relist = array( '' => '(?:(?<!\*)\*\*(?!\*)|(?<!_)__(?!_))(?![\.,:;]?\s)', '**' => '(?<![\s*])\*\*(?!\*)', '__' => '(?<![\s_])__(?!_)', ); protected $em_strong_relist = array( '' => '(?:(?<!\*)\*\*\*(?!\*)|(?<!_)___(?!_))(?![\.,:;]?\s)', '***' => '(?<![\s*])\*\*\*(?!\*)', '___' => '(?<![\s_])___(?!_)', ); protected $em_strong_prepared_relist; protected function prepareItalicsAndBold() { foreach ($this->em_relist as $em => $em_re) { foreach ($this->strong_relist as $strong => $strong_re) { $token_relist = array(); if (isset($this->em_strong_relist["$em$strong"])) { $token_relist[] = $this->em_strong_relist["$em$strong"]; } $token_relist[] = $em_re; $token_relist[] = $strong_re; $token_re = '{(' . implode('|', $token_relist) . ')}'; $this->em_strong_prepared_relist["$em$strong"] = $token_re; } } } protected function doItalicsAndBold($text) { $token_stack = array(''); $text_stack = array(''); $em = ''; $strong = ''; $tree_char_em = false; while (1) { $token_re = $this->em_strong_prepared_relist["$em$strong"]; $parts = preg_split($token_re, $text, 2, PREG_SPLIT_DELIM_CAPTURE); $text_stack[0] .= $parts[0]; $token =& $parts[1]; $text =& $parts[2]; if (empty($token)) { while ($token_stack[0]) { $text_stack[1] .= array_shift($token_stack); $text_stack[0] .= array_shift($text_stack); } break; } $token_len = strlen($token); if ($tree_char_em) { if ($token_len == 3) { array_shift($token_stack); $span = array_shift($text_stack); $span = $this->runSpanGamut($span); $span = "<strong><em>$span</em></strong>"; $text_stack[0] .= $this->hashPart($span); $em = ''; $strong = ''; } else { $token_stack[0] = str_repeat($token{0}, 3 - $token_len); $tag = $token_len == 2 ? "strong" : "em"; $span = $text_stack[0]; $span = $this->runSpanGamut($span); $span = "<$tag>$span</$tag>"; $text_stack[0] = $this->hashPart($span); $$tag = ''; } $tree_char_em = false; } else { if ($token_len == 3) { if ($em) { for ($i = 0; $i < 2; ++$i) { $shifted_token = array_shift($token_stack); $tag = strlen($shifted_token) == 2 ? "strong" : "em"; $span = array_shift($text_stack); $span = $this->runSpanGamut($span); $span = "<$tag>$span</$tag>"; $text_stack[0] .= $this->hashPart($span); $$tag = ''; } } else { $em = $token{0}; $strong = "$em$em"; array_unshift($token_stack, $token); array_unshift($text_stack, ''); $tree_char_em = true; } } else { if ($token_len == 2) { if ($strong) { if (strlen($token_stack[0]) == 1) { $text_stack[1] .= array_shift($token_stack); $text_stack[0] .= array_shift($text_stack); } array_shift($token_stack); $span = array_shift($text_stack); $span = $this->runSpanGamut($span); $span = "<strong>$span</strong>"; $text_stack[0] .= $this->hashPart($span); $strong = ''; } else { array_unshift($token_stack, $token); array_unshift($text_stack, ''); $strong = $token; } } else { if ($em) { if (strlen($token_stack[0]) == 1) { array_shift($token_stack); $span = array_shift($text_stack); $span = $this->runSpanGamut($span); $span = "<em>$span</em>"; $text_stack[0] .= $this->hashPart($span); $em = ''; } else { $text_stack[0] .= $token; } } else { array_unshift($token_stack, $token); array_unshift($text_stack, ''); $em = $token; } } } } } return $text_stack[0]; } protected function doBlockQuotes($text) { $text = preg_replace_callback('/
    			  (								# Wrap whole match in $1
    				(?>
    				  ^[ ]*>[ ]?			# ">" at the start of a line
    					.+\n					# rest of the first line
    				  (.+\n)*					# subsequent consecutive lines
    				  \n*						# blanks
    				)+
    			  )
    			/xm', array($this, '_doBlockQuotes_callback'), $text); return $text; } protected function _doBlockQuotes_callback($matches) { $bq = $matches[1]; $bq = preg_replace('/^[ ]*>[ ]?|^[ ]+$/m', '', $bq); $bq = $this->runBlockGamut($bq); $bq = preg_replace('/^/m', "  ", $bq); $bq = preg_replace_callback('{(\s*<pre>.+?</pre>)}sx', array($this, '_doBlockQuotes_callback2'), $bq); return "\n" . $this->hashBlock("<blockquote>\n$bq\n</blockquote>") . "\n\n"; } protected function _doBlockQuotes_callback2($matches) { $pre = $matches[1]; $pre = preg_replace('/^  /m', '', $pre); return $pre; } protected function formParagraphs($text) { $text = preg_replace('/\A\n+|\n+\z/', '', $text); $grafs = preg_split('/\n{2,}/', $text, -1, PREG_SPLIT_NO_EMPTY); foreach ($grafs as $key => $value) { if (!preg_match('/^B\x1A[0-9]+B$/', $value)) { $value = $this->runSpanGamut($value); $value = preg_replace('/^([ ]*)/', "<p>", $value); $value .= "</p>"; $grafs[$key] = $this->unhash($value); } else { $graf = $value; $block = $this->html_hashes[$graf]; $graf = $block; $grafs[$key] = $graf; } } return implode("\n\n", $grafs); } protected function encodeAttribute($text) { $text = $this->encodeAmpsAndAngles($text); $text = str_replace('"', '&quot;', $text); return $text; } protected function encodeURLAttribute($url, &$text = null) { if ($this->url_filter_func) { $url = call_user_func($this->url_filter_func, $url); } if (preg_match('{^mailto:}i', $url)) { $url = $this->encodeEntityObfuscatedAttribute($url, $text, 7); } else { if (preg_match('{^tel:}i', $url)) { $url = $this->encodeAttribute($url); $text = substr($url, 4); } else { $url = $this->encodeAttribute($url); $text = $url; } } return $url; } protected function encodeAmpsAndAngles($text) { if ($this->no_entities) { $text = str_replace('&', '&amp;', $text); } else { $text = preg_replace('/&(?!#?[xX]?(?:[0-9a-fA-F]+|\w+);)/', '&amp;', $text); } $text = str_replace('<', '&lt;', $text); return $text; } protected function doAutoLinks($text) { $text = preg_replace_callback('{<((https?|ftp|dict|tel):[^\'">\s]+)>}i', array($this, '_doAutoLinks_url_callback'), $text); $text = preg_replace_callback('{
    			<
    			(?:mailto:)?
    			(
    				(?:
    					[-!#$%&\'*+/=?^_`.{|}~\w\x80-\xFF]+
    				|
    					".*?"
    				)
    				\@
    				(?:
    					[-a-z0-9\x80-\xFF]+(\.[-a-z0-9\x80-\xFF]+)*\.[a-z]+
    				|
    					\[[\d.a-fA-F:]+\]	# IPv4 & IPv6
    				)
    			)
    			>
    			}xi', array($this, '_doAutoLinks_email_callback'), $text); return $text; } protected function _doAutoLinks_url_callback($matches) { $url = $this->encodeURLAttribute($matches[1], $text); $link = "<a href=\"$url\">$text</a>"; return $this->hashPart($link); } protected function _doAutoLinks_email_callback($matches) { $addr = $matches[1]; $url = $this->encodeURLAttribute("mailto:$addr", $text); $link = "<a href=\"$url\">$text</a>"; return $this->hashPart($link); } protected function encodeEntityObfuscatedAttribute($text, &$tail = null, $head_length = 0) { if ($text == "") { return $tail = ""; } $chars = preg_split('/(?<!^)(?!$)/', $text); $seed = (int)abs(crc32($text) / strlen($text)); foreach ($chars as $key => $char) { $ord = ord($char); if ($ord < 128) { $r = ($seed * (1 + $key)) % 100; if ($r > 90 && strpos('@"&>', $char) === false) { ; } else { if ($r < 45) { $chars[$key] = '&#x' . dechex($ord) . ';'; } else { $chars[$key] = '&#' . $ord . ';'; } } } } $text = implode('', $chars); $tail = $head_length ? implode('', array_slice($chars, $head_length)) : $text; return $text; } protected function parseSpan($str) { $output = ''; $span_re = '{
    				(
    					\\\\' . $this->escape_chars_re . '
    				|
    					(?<![`\\\\])
    					`+						# code span marker
    			' . ($this->no_markup ? '' : '
    				|
    					<!--    .*?     -->		# comment
    				|
    					<\?.*?\?> | <%.*?%>		# processing instruction
    				|
    					<[!$]?[-a-zA-Z0-9:_]+	# regular tags
    					(?>
    						\s
    						(?>[^"\'>]+|"[^"]*"|\'[^\']*\')*
    					)?
    					>
    				|
    					<[-a-zA-Z0-9:_]+\s*/> # xml-style empty tag
    				|
    					</[-a-zA-Z0-9:_]+\s*> # closing tag
    			') . '
    				)
    				}xs'; while (1) { $parts = preg_split($span_re, $str, 2, PREG_SPLIT_DELIM_CAPTURE); if ($parts[0] != "") { $output .= $parts[0]; } if (isset($parts[1])) { $output .= $this->handleSpanToken($parts[1], $parts[2]); $str = $parts[2]; } else { break; } } return $output; } protected function handleSpanToken($token, &$str) { switch ($token{0}) { case "\\": return $this->hashPart("&#" . ord($token{1}) . ";"); case "`": if (preg_match('/^(.*?[^`])' . preg_quote($token) . '(?!`)(.*)$/sm', $str, $matches)) { $str = $matches[2]; $codespan = $this->makeCodeSpan($matches[1]); return $this->hashPart($codespan); } return $token; default: return $this->hashPart($token); } } protected function outdent($text) { return preg_replace('/^(\t|[ ]{1,' . $this->tab_width . '})/m', '', $text); } protected $utf8_strlen = 'mb_strlen'; protected function detab($text) { $text = preg_replace_callback('/^.*\t.*$/m', array($this, '_detab_callback'), $text); return $text; } protected function _detab_callback($matches) { $line = $matches[0]; $strlen = $this->utf8_strlen; $blocks = explode("\t", $line); $line = $blocks[0]; unset($blocks[0]); foreach ($blocks as $block) { $amount = $this->tab_width - $strlen($line, 'UTF-8') % $this->tab_width; $line .= str_repeat(" ", $amount) . $block; } return $line; } protected function _initDetab() { if (function_exists($this->utf8_strlen)) { return; } $this->utf8_strlen = create_function('$text', 'return preg_match_all(
    			"/[\\\\x00-\\\\xBF]|[\\\\xC0-\\\\xFF][\\\\x80-\\\\xBF]*/", 
    			$text, $m);'); } protected function unhash($text) { return preg_replace_callback('/(.)\x1A[0-9]+\1/', array($this, '_unhash_callback'), $text); } protected function _unhash_callback($matches) { return $this->html_hashes[$matches[0]]; } } class MarkdownExtra extends \Michelf\Markdown { public $fn_id_prefix = ""; public $fn_link_title = ""; public $fn_backlink_title = ""; public $fn_link_class = "footnote-ref"; public $fn_backlink_class = "footnote-backref"; public $table_align_class_tmpl = ''; public $code_class_prefix = ""; public $code_attr_on_pre = false; public $predef_abbr = array(); public function __construct() { $this->escape_chars .= ':|'; $this->document_gamut += array( "doFencedCodeBlocks" => 5, "stripFootnotes" => 15, "stripAbbreviations" => 25, "appendFootnotes" => 50, ); $this->block_gamut += array( "doFencedCodeBlocks" => 5, "doTables" => 15, "doDefLists" => 45, ); $this->span_gamut += array( "doFootnotes" => 5, "doAbbreviations" => 70, ); $this->enhanced_ordered_list = true; parent::__construct(); } protected $footnotes = array(); protected $footnotes_ordered = array(); protected $footnotes_ref_count = array(); protected $footnotes_numbers = array(); protected $abbr_desciptions = array(); protected $abbr_word_re = ''; protected $footnote_counter = 1; protected function setup() { parent::setup(); $this->footnotes = array(); $this->footnotes_ordered = array(); $this->footnotes_ref_count = array(); $this->footnotes_numbers = array(); $this->abbr_desciptions = array(); $this->abbr_word_re = ''; $this->footnote_counter = 1; foreach ($this->predef_abbr as $abbr_word => $abbr_desc) { if ($this->abbr_word_re) { $this->abbr_word_re .= '|'; } $this->abbr_word_re .= preg_quote($abbr_word); $this->abbr_desciptions[$abbr_word] = trim($abbr_desc); } } protected function teardown() { $this->footnotes = array(); $this->footnotes_ordered = array(); $this->footnotes_ref_count = array(); $this->footnotes_numbers = array(); $this->abbr_desciptions = array(); $this->abbr_word_re = ''; parent::teardown(); } protected $id_class_attr_catch_re = '\{((?:[ ]*[#.a-z][-_:a-zA-Z0-9=]+){1,})[ ]*\}'; protected $id_class_attr_nocatch_re = '\{(?:[ ]*[#.a-z][-_:a-zA-Z0-9=]+){1,}[ ]*\}'; protected function doExtraAttributes($tag_name, $attr, $defaultIdValue = null) { if (empty($attr) && !$defaultIdValue) { return ""; } preg_match_all('/[#.a-z][-_:a-zA-Z0-9=]+/', $attr, $matches); $elements = $matches[0]; $classes = array(); $attributes = array(); $id = false; foreach ($elements as $element) { if ($element{0} == '.') { $classes[] = substr($element, 1); } else { if ($element{0} == '#') { if ($id === false) { $id = substr($element, 1); } } else { if (strpos($element, '=') > 0) { $parts = explode('=', $element, 2); $attributes[] = $parts[0] . '="' . $parts[1] . '"'; } } } } if (!$id) { $id = $defaultIdValue; } $attr_str = ""; if (!empty($id)) { $attr_str .= ' id="' . $this->encodeAttribute($id) . '"'; } if (!empty($classes)) { $attr_str .= ' class="' . implode(" ", $classes) . '"'; } if (!$this->no_markup && !empty($attributes)) { $attr_str .= ' ' . implode(" ", $attributes); } return $attr_str; } protected function stripLinkDefinitions($text) { $less_than_tab = $this->tab_width - 1; $text = preg_replace_callback('{
    							^[ ]{0,' . $less_than_tab . '}\[(.+)\][ ]?:	# id = $1
    							  [ ]*
    							  \n?				# maybe *one* newline
    							  [ ]*
    							(?:
    							  <(.+?)>			# url = $2
    							|
    							  (\S+?)			# url = $3
    							)
    							  [ ]*
    							  \n?				# maybe one newline
    							  [ ]*
    							(?:
    								(?<=\s)			# lookbehind for whitespace
    								["(]
    								(.*?)			# title = $4
    								[")]
    								[ ]*
    							)?	# title is optional
    					(?:[ ]* ' . $this->id_class_attr_catch_re . ' )?  # $5 = extra id & class attr
    							(?:\n+|\Z)
    			}xm', array($this, '_stripLinkDefinitions_callback'), $text); return $text; } protected function _stripLinkDefinitions_callback($matches) { $link_id = strtolower($matches[1]); $url = $matches[2] == '' ? $matches[3] : $matches[2]; $this->urls[$link_id] = $url; $this->titles[$link_id] =& $matches[4]; $this->ref_attr[$link_id] = $this->doExtraAttributes("", $dummy =& $matches[5]); return ''; } protected $block_tags_re = 'p|div|h[1-6]|blockquote|pre|table|dl|ol|ul|address|form|fieldset|iframe|hr|legend|article|section|nav|aside|hgroup|header|footer|figcaption|figure'; protected $context_block_tags_re = 'script|noscript|style|ins|del|iframe|object|source|track|param|math|svg|canvas|audio|video'; protected $contain_span_tags_re = 'p|h[1-6]|li|dd|dt|td|th|legend|address'; protected $clean_tags_re = 'script|style|math|svg'; protected $auto_close_tags_re = 'hr|img|param|source|track'; protected function hashHTMLBlocks($text) { if ($this->no_markup) { return $text; } list($text,) = $this->_hashHTMLBlocks_inMarkdown($text); return $text; } protected function _hashHTMLBlocks_inMarkdown( $text, $indent = 0, $enclosing_tag_re = '', $span = false ) { if ($text === '') { return array('', ''); } $newline_before_re = '/(?:^\n?|\n\n)*$/'; $newline_after_re = '{
    				^						# Start of text following the tag.
    				(?>[ ]*<!--.*?-->)?		# Optional comment.
    				[ ]*\n					# Must be followed by newline.
    			}xs'; $block_tag_re = '{
    				(					# $2: Capture whole tag.
    					</?					# Any opening or closing tag.
    						(?>				# Tag name.
    							' . $this->block_tags_re . '			|
    							' . $this->context_block_tags_re . '	|
    							' . $this->clean_tags_re . '        	|
    							(?!\s)' . $enclosing_tag_re . '
    						)
    						(?:
    							(?=[\s"\'/a-zA-Z0-9])	# Allowed characters after tag name.
    							(?>
    								".*?"		|	# Double quotes (can contain `>`)
    								\'.*?\'   	|	# Single quotes (can contain `>`)
    								.+?				# Anything but quotes and `>`.
    							)*?
    						)?
    					>					# End of tag.
    				|
    					<!--    .*?     -->	# HTML Comment
    				|
    					<\?.*?\?> | <%.*?%>	# Processing instruction
    				|
    					<!\[CDATA\[.*?\]\]>	# CData Block
    				' . (!$span ? ' # If not in span.
    				|
    					# Indented code block
    					(?: ^[ ]*\n | ^ | \n[ ]*\n )
    					[ ]{' . ($indent + 4) . '}[^\n]* \n
    					(?>
    						(?: [ ]{' . ($indent + 4) . '}[^\n]* | [ ]* ) \n
    					)*
    				|
    					# Fenced code block marker
    					(?<= ^ | \n )
    					[ ]{0,' . ($indent + 3) . '}(?:~{3,}|`{3,})
    									[ ]*
    					(?:
    					\.?[-_:a-zA-Z0-9]+ # standalone class name
    					|
    						' . $this->id_class_attr_nocatch_re . ' # extra attributes
    					)?
    					[ ]*
    					(?= \n )
    				' : '') . ' # End (if not is span).
    				|
    					# Code span marker
    					# Note, this regex needs to go after backtick fenced
    					# code blocks but it should also be kept outside of the
    					# "if not in span" condition adding backticks to the parser
    					`+
    				)
    			}xs'; $depth = 0; $parsed = ""; do { $parts = preg_split($block_tag_re, $text, 2, PREG_SPLIT_DELIM_CAPTURE); if ($span) { $void = $this->hashPart("", ':'); $newline = "$void\n"; $parts[0] = $void . str_replace("\n", $newline, $parts[0]) . $void; } $parsed .= $parts[0]; if (count($parts) < 3) { $text = ""; break; } $tag = $parts[1]; $text = $parts[2]; $tag_re = preg_quote($tag); if (preg_match('{^\n?([ ]{0,' . ($indent + 3) . '})(~{3,}|`{3,})[ ]*(?:\.?[-_:a-zA-Z0-9]+|' . $this->id_class_attr_nocatch_re . ')?[ ]*\n?$}', $tag, $capture)) { $fence_indent = strlen($capture[1]); $fence_re = $capture[2]; if (preg_match('{^(?>.*\n)*?[ ]{' . ($fence_indent) . '}' . $fence_re . '[ ]*(?:\n|$)}', $text, $matches)) { $parsed .= $tag . $matches[0]; $text = substr($text, strlen($matches[0])); } else { $parsed .= $tag; } } else { if ($tag{0} == "\n" || $tag{0} == " ") { $parsed .= $tag; } else { if ($tag{0} == "`") { $tag_re = preg_quote($tag); if (preg_match('{^(?>.+?|\n(?!\n))*?(?<!`)' . $tag_re . '(?!`)}', $text, $matches)) { $parsed .= $tag . $matches[0]; $text = substr($text, strlen($matches[0])); } else { $parsed .= $tag; } } else { if (preg_match('{^<(?:' . $this->block_tags_re . ')\b}', $tag) || (preg_match('{^<(?:' . $this->context_block_tags_re . ')\b}', $tag) && preg_match($newline_before_re, $parsed) && preg_match($newline_after_re, $text)) ) { list($block_text, $text) = $this->_hashHTMLBlocks_inHTML($tag . $text, "hashBlock", true); $parsed .= "\n\n$block_text\n\n"; } else { if (preg_match('{^<(?:' . $this->clean_tags_re . ')\b}', $tag) || $tag{1} == '!' || $tag{1} == '?' ) { list($block_text, $text) = $this->_hashHTMLBlocks_inHTML($tag . $text, "hashClean", false); $parsed .= $block_text; } else { if ($enclosing_tag_re !== '' && preg_match('{^</?(?:' . $enclosing_tag_re . ')\b}', $tag) ) { if ($tag{1} == '/') { $depth--; } else { if ($tag{strlen($tag) - 2} != '/') { $depth++; } } if ($depth < 0) { $text = $tag . $text; break; } $parsed .= $tag; } else { $parsed .= $tag; } } } } } } } while ($depth >= 0); return array($parsed, $text); } protected function _hashHTMLBlocks_inHTML($text, $hash_method, $md_attr) { if ($text === '') { return array('', ''); } $markdown_attr_re = '
    			{
    				\s*			# Eat whitespace before the `markdown` attribute
    				markdown
    				\s*=\s*
    				(?>
    					(["\'])		# $1: quote delimiter		
    					(.*?)		# $2: attribute value
    					\1			# matching delimiter	
    				|
    					([^\s>]*)	# $3: unquoted attribute value
    				)
    				()				# $4: make $3 always defined (avoid warnings)
    			}xs'; $tag_re = '{
    				(					# $2: Capture whole tag.
    					</?					# Any opening or closing tag.
    						[\w:$]+			# Tag name.
    						(?:
    							(?=[\s"\'/a-zA-Z0-9])	# Allowed characters after tag name.
    							(?>
    								".*?"		|	# Double quotes (can contain `>`)
    								\'.*?\'   	|	# Single quotes (can contain `>`)
    								.+?				# Anything but quotes and `>`.
    							)*?
    						)?
    					>					# End of tag.
    				|
    					<!--    .*?     -->	# HTML Comment
    				|
    					<\?.*?\?> | <%.*?%>	# Processing instruction
    				|
    					<!\[CDATA\[.*?\]\]>	# CData Block
    				)
    			}xs'; $original_text = $text; $depth = 0; $block_text = ""; $parsed = ""; if (preg_match('/^<([\w:$]*)\b/', $text, $matches)) { $base_tag_name_re = $matches[1]; } do { $parts = preg_split($tag_re, $text, 2, PREG_SPLIT_DELIM_CAPTURE); if (count($parts) < 3) { return array($original_text{0}, substr($original_text, 1)); } $block_text .= $parts[0]; $tag = $parts[1]; $text = $parts[2]; if (preg_match('{^</?(?:' . $this->auto_close_tags_re . ')\b}', $tag) || $tag{1} == '!' || $tag{1} == '?' ) { $block_text .= $tag; } else { if (preg_match('{^</?' . $base_tag_name_re . '\b}', $tag)) { if ($tag{1} == '/') { $depth--; } else { if ($tag{strlen($tag) - 2} != '/') { $depth++; } } } if ($md_attr && preg_match($markdown_attr_re, $tag, $attr_m) && preg_match('/^1|block|span$/', $attr_m[2] . $attr_m[3]) ) { $tag = preg_replace($markdown_attr_re, '', $tag); $this->mode = $attr_m[2] . $attr_m[3]; $span_mode = $this->mode == 'span' || $this->mode != 'block' && preg_match('{^<(?:' . $this->contain_span_tags_re . ')\b}', $tag); if (preg_match('/(?:^|\n)( *?)(?! ).*?$/', $block_text, $matches)) { $strlen = $this->utf8_strlen; $indent = $strlen($matches[1], 'UTF-8'); } else { $indent = 0; } $block_text .= $tag; $parsed .= $this->$hash_method($block_text); preg_match('/^<([\w:$]*)\b/', $tag, $matches); $tag_name_re = $matches[1]; list ($block_text, $text) = $this->_hashHTMLBlocks_inMarkdown($text, $indent, $tag_name_re, $span_mode); if ($indent > 0) { $block_text = preg_replace("/^[ ]{1,$indent}/m", "", $block_text); } if (!$span_mode) { $parsed .= "\n\n$block_text\n\n"; } else { $parsed .= "$block_text"; } $block_text = ""; } else { $block_text .= $tag; } } } while ($depth > 0); $parsed .= $this->$hash_method($block_text); return array($parsed, $text); } protected function hashClean($text) { return $this->hashPart($text, 'C'); } protected function doAnchors($text) { if ($this->in_anchor) { return $text; } $this->in_anchor = true; $text = preg_replace_callback('{
    			(					# wrap whole match in $1
    			  \[
    				(' . $this->nested_brackets_re . ')	# link text = $2
    			  \]
    
    			  [ ]?				# one optional space
    			  (?:\n[ ]*)?		# one optional newline followed by spaces
    
    			  \[
    				(.*?)		# id = $3
    			  \]
    			)
    			}xs', array($this, '_doAnchors_reference_callback'), $text); $text = preg_replace_callback('{
    			(				# wrap whole match in $1
    			  \[
    				(' . $this->nested_brackets_re . ')	# link text = $2
    			  \]
    			  \(			# literal paren
    				[ \n]*
    				(?:
    					<(.+?)>	# href = $3
    				|
    					(' . $this->nested_url_parenthesis_re . ')	# href = $4
    				)
    				[ \n]*
    				(			# $5
    				  ([\'"])	# quote char = $6
    				  (.*?)		# Title = $7
    				  \6		# matching quote
    				  [ \n]*	# ignore any spaces/tabs between closing quote and )
    				)?			# title is optional
    			  \)
    			  (?:[ ]? ' . $this->id_class_attr_catch_re . ' )?	 # $8 = id/class attributes
    			)
    			}xs', array($this, '_doAnchors_inline_callback'), $text); $text = preg_replace_callback('{
    			(					# wrap whole match in $1
    			  \[
    				([^\[\]]+)		# link text = $2; can\'t contain [ or ]
    			  \]
    			)
    			}xs', array($this, '_doAnchors_reference_callback'), $text); $this->in_anchor = false; return $text; } protected function _doAnchors_reference_callback($matches) { $whole_match = $matches[1]; $link_text = $matches[2]; $link_id =& $matches[3]; if ($link_id == "") { $link_id = $link_text; } $link_id = strtolower($link_id); $link_id = preg_replace('{[ ]?\n}', ' ', $link_id); if (isset($this->urls[$link_id])) { $url = $this->urls[$link_id]; $url = $this->encodeURLAttribute($url); $result = "<a href=\"$url\""; if (isset($this->titles[$link_id])) { $title = $this->titles[$link_id]; $title = $this->encodeAttribute($title); $result .= " title=\"$title\""; } if (isset($this->ref_attr[$link_id])) { $result .= $this->ref_attr[$link_id]; } $link_text = $this->runSpanGamut($link_text); $result .= ">$link_text</a>"; $result = $this->hashPart($result); } else { $result = $whole_match; } return $result; } protected function _doAnchors_inline_callback($matches) { $whole_match = $matches[1]; $link_text = $this->runSpanGamut($matches[2]); $url = $matches[3] == '' ? $matches[4] : $matches[3]; $title =& $matches[7]; $attr = $this->doExtraAttributes("a", $dummy =& $matches[8]); $unhashed = $this->unhash($url); if ($unhashed != $url) { $url = preg_replace('/^<(.*)>$/', '\1', $unhashed); } $url = $this->encodeURLAttribute($url); $result = "<a href=\"$url\""; if (isset($title)) { $title = $this->encodeAttribute($title); $result .= " title=\"$title\""; } $result .= $attr; $link_text = $this->runSpanGamut($link_text); $result .= ">$link_text</a>"; return $this->hashPart($result); } protected function doImages($text) { $text = preg_replace_callback('{
    			(				# wrap whole match in $1
    			  !\[
    				(' . $this->nested_brackets_re . ')		# alt text = $2
    			  \]
    
    			  [ ]?				# one optional space
    			  (?:\n[ ]*)?		# one optional newline followed by spaces
    
    			  \[
    				(.*?)		# id = $3
    			  \]
    
    			)
    			}xs', array($this, '_doImages_reference_callback'), $text); $text = preg_replace_callback('{
    			(				# wrap whole match in $1
    			  !\[
    				(' . $this->nested_brackets_re . ')		# alt text = $2
    			  \]
    			  \s?			# One optional whitespace character
    			  \(			# literal paren
    				[ \n]*
    				(?:
    					<(\S*)>	# src url = $3
    				|
    					(' . $this->nested_url_parenthesis_re . ')	# src url = $4
    				)
    				[ \n]*
    				(			# $5
    				  ([\'"])	# quote char = $6
    				  (.*?)		# title = $7
    				  \6		# matching quote
    				  [ \n]*
    				)?			# title is optional
    			  \)
    			  (?:[ ]? ' . $this->id_class_attr_catch_re . ' )?	 # $8 = id/class attributes
    			)
    			}xs', array($this, '_doImages_inline_callback'), $text); return $text; } protected function _doImages_reference_callback($matches) { $whole_match = $matches[1]; $alt_text = $matches[2]; $link_id = strtolower($matches[3]); if ($link_id == "") { $link_id = strtolower($alt_text); } $alt_text = $this->encodeAttribute($alt_text); if (isset($this->urls[$link_id])) { $url = $this->encodeURLAttribute($this->urls[$link_id]); $result = "<img src=\"$url\" alt=\"$alt_text\""; if (isset($this->titles[$link_id])) { $title = $this->titles[$link_id]; $title = $this->encodeAttribute($title); $result .= " title=\"$title\""; } if (isset($this->ref_attr[$link_id])) { $result .= $this->ref_attr[$link_id]; } $result .= $this->empty_element_suffix; $result = $this->hashPart($result); } else { $result = $whole_match; } return $result; } protected function _doImages_inline_callback($matches) { $whole_match = $matches[1]; $alt_text = $matches[2]; $url = $matches[3] == '' ? $matches[4] : $matches[3]; $title =& $matches[7]; $attr = $this->doExtraAttributes("img", $dummy =& $matches[8]); $alt_text = $this->encodeAttribute($alt_text); $url = $this->encodeURLAttribute($url); $result = "<img src=\"$url\" alt=\"$alt_text\""; if (isset($title)) { $title = $this->encodeAttribute($title); $result .= " title=\"$title\""; } $result .= $attr; $result .= $this->empty_element_suffix; return $this->hashPart($result); } protected function doHeaders($text) { $text = preg_replace_callback( '{
    				(^.+?)								# $1: Header text
    				(?:[ ]+ ' . $this->id_class_attr_catch_re . ' )?	 # $3 = id/class attributes
    				[ ]*\n(=+|-+)[ ]*\n+				# $3: Header footer
    			}mx', array($this, '_doHeaders_callback_setext'), $text); $text = preg_replace_callback('{
    				^(\#{1,6})	# $1 = string of #\'s
    				[ ]*
    				(.+?)		# $2 = Header text
    				[ ]*
    				\#*			# optional closing #\'s (not counted)
    				(?:[ ]+ ' . $this->id_class_attr_catch_re . ' )?	 # $3 = id/class attributes
    				[ ]*
    				\n+
    			}xm', array($this, '_doHeaders_callback_atx'), $text); return $text; } protected function _doHeaders_callback_setext($matches) { if ($matches[3] == '-' && preg_match('{^- }', $matches[1])) { return $matches[0]; } $level = $matches[3]{0} == '=' ? 1 : 2; $defaultId = is_callable($this->header_id_func) ? call_user_func($this->header_id_func, $matches[1]) : null; $attr = $this->doExtraAttributes("h$level", $dummy =& $matches[2], $defaultId); $block = "<h$level$attr>" . $this->runSpanGamut($matches[1]) . "</h$level>"; return "\n" . $this->hashBlock($block) . "\n\n"; } protected function _doHeaders_callback_atx($matches) { $level = strlen($matches[1]); $defaultId = is_callable($this->header_id_func) ? call_user_func($this->header_id_func, $matches[2]) : null; $attr = $this->doExtraAttributes("h$level", $dummy =& $matches[3], $defaultId); $block = "<h$level$attr>" . $this->runSpanGamut($matches[2]) . "</h$level>"; return "\n" . $this->hashBlock($block) . "\n\n"; } protected function doTables($text) { $less_than_tab = $this->tab_width - 1; $text = preg_replace_callback('
    			{
    				^							# Start of a line
    				[ ]{0,' . $less_than_tab . '}	# Allowed whitespace.
    				[|]							# Optional leading pipe (present)
    				(.+) \n						# $1: Header row (at least one pipe)
    				
    				[ ]{0,' . $less_than_tab . '}	# Allowed whitespace.
    				[|] ([ ]*[-:]+[-| :]*) \n	# $2: Header underline
    				
    				(							# $3: Cells
    					(?>
    						[ ]*				# Allowed whitespace.
    						[|] .* \n			# Row content.
    					)*
    				)
    				(?=\n|\Z)					# Stop at final double newline.
    			}xm', array($this, '_doTable_leadingPipe_callback'), $text); $text = preg_replace_callback('
    			{
    				^							# Start of a line
    				[ ]{0,' . $less_than_tab . '}	# Allowed whitespace.
    				(\S.*[|].*) \n				# $1: Header row (at least one pipe)
    				
    				[ ]{0,' . $less_than_tab . '}	# Allowed whitespace.
    				([-:]+[ ]*[|][-| :]*) \n	# $2: Header underline
    				
    				(							# $3: Cells
    					(?>
    						.* [|] .* \n		# Row content
    					)*
    				)
    				(?=\n|\Z)					# Stop at final double newline.
    			}xm', array($this, '_DoTable_callback'), $text); return $text; } protected function _doTable_leadingPipe_callback($matches) { $head = $matches[1]; $underline = $matches[2]; $content = $matches[3]; $content = preg_replace('/^ *[|]/m', '', $content); return $this->_doTable_callback(array($matches[0], $head, $underline, $content)); } protected function _doTable_makeAlignAttr($alignname) { if (empty($this->table_align_class_tmpl)) { return " align=\"$alignname\""; } $classname = str_replace('%%', $alignname, $this->table_align_class_tmpl); return " class=\"$classname\""; } protected function _doTable_callback($matches) { $head = $matches[1]; $underline = $matches[2]; $content = $matches[3]; $head = preg_replace('/[|] *$/m', '', $head); $underline = preg_replace('/[|] *$/m', '', $underline); $content = preg_replace('/[|] *$/m', '', $content); $separators = preg_split('/ *[|] */', $underline); foreach ($separators as $n => $s) { if (preg_match('/^ *-+: *$/', $s)) { $attr[$n] = $this->_doTable_makeAlignAttr('right'); } else { if (preg_match('/^ *:-+: *$/', $s)) { $attr[$n] = $this->_doTable_makeAlignAttr('center'); } else { if (preg_match('/^ *:-+ *$/', $s)) { $attr[$n] = $this->_doTable_makeAlignAttr('left'); } else { $attr[$n] = ''; } } } } $head = $this->parseSpan($head); $headers = preg_split('/ *[|] */', $head); $col_count = count($headers); $attr = array_pad($attr, $col_count, ''); $text = "<table>\n"; $text .= "<thead>\n"; $text .= "<tr>\n"; foreach ($headers as $n => $header) { $text .= "  <th$attr[$n]>" . $this->runSpanGamut(trim($header)) . "</th>\n"; } $text .= "</tr>\n"; $text .= "</thead>\n"; $rows = explode("\n", trim($content, "\n")); $text .= "<tbody>\n"; foreach ($rows as $row) { $row = $this->parseSpan($row); $row_cells = preg_split('/ *[|] */', $row, $col_count); $row_cells = array_pad($row_cells, $col_count, ''); $text .= "<tr>\n"; foreach ($row_cells as $n => $cell) { $text .= "  <td$attr[$n]>" . $this->runSpanGamut(trim($cell)) . "</td>\n"; } $text .= "</tr>\n"; } $text .= "</tbody>\n"; $text .= "</table>"; return $this->hashBlock($text) . "\n"; } protected function doDefLists($text) { $less_than_tab = $this->tab_width - 1; $whole_list_re = '(?>
    			(								# $1 = whole list
    			  (								# $2
    				[ ]{0,' . $less_than_tab . '}
    				((?>.*\S.*\n)+)				# $3 = defined term
    				\n?
    				[ ]{0,' . $less_than_tab . '}:[ ]+ # colon starting definition
    			  )
    			  (?s:.+?)
    			  (								# $4
    				  \z
    				|
    				  \n{2,}
    				  (?=\S)
    				  (?!						# Negative lookahead for another term
    					[ ]{0,' . $less_than_tab . '}
    					(?: \S.*\n )+?			# defined term
    					\n?
    					[ ]{0,' . $less_than_tab . '}:[ ]+ # colon starting definition
    				  )
    				  (?!						# Negative lookahead for another definition
    					[ ]{0,' . $less_than_tab . '}:[ ]+ # colon starting definition
    				  )
    			  )
    			)
    		)'; $text = preg_replace_callback('{
    				(?>\A\n?|(?<=\n\n))
    				' . $whole_list_re . '
    			}mx', array($this, '_doDefLists_callback'), $text); return $text; } protected function _doDefLists_callback($matches) { $list = $matches[1]; $result = trim($this->processDefListItems($list)); $result = "<dl>\n" . $result . "\n</dl>"; return $this->hashBlock($result) . "\n\n"; } protected function processDefListItems($list_str) { $less_than_tab = $this->tab_width - 1; $list_str = preg_replace("/\n{2,}\\z/", "\n", $list_str); $list_str = preg_replace_callback('{
    			(?>\A\n?|\n\n+)					# leading line
    			(								# definition terms = $1
    				[ ]{0,' . $less_than_tab . '}	# leading whitespace
    				(?!\:[ ]|[ ])				# negative lookahead for a definition
    											#   mark (colon) or more whitespace.
    				(?> \S.* \n)+?				# actual term (not whitespace).	
    			)			
    			(?=\n?[ ]{0,3}:[ ])				# lookahead for following line feed 
    											#   with a definition mark.
    			}xm', array($this, '_processDefListItems_callback_dt'), $list_str); $list_str = preg_replace_callback('{
    			\n(\n+)?						# leading line = $1
    			(								# marker space = $2
    				[ ]{0,' . $less_than_tab . '}	# whitespace before colon
    				\:[ ]+						# definition mark (colon)
    			)
    			((?s:.+?))						# definition text = $3
    			(?= \n+ 						# stop at next definition mark,
    				(?:							# next term or end of text
    					[ ]{0,' . $less_than_tab . '} \:[ ]	|
    					<dt> | \z
    				)						
    			)					
    			}xm', array($this, '_processDefListItems_callback_dd'), $list_str); return $list_str; } protected function _processDefListItems_callback_dt($matches) { $terms = explode("\n", trim($matches[1])); $text = ''; foreach ($terms as $term) { $term = $this->runSpanGamut(trim($term)); $text .= "\n<dt>" . $term . "</dt>"; } return $text . "\n"; } protected function _processDefListItems_callback_dd($matches) { $leading_line = $matches[1]; $marker_space = $matches[2]; $def = $matches[3]; if ($leading_line || preg_match('/\n{2,}/', $def)) { $def = str_repeat(' ', strlen($marker_space)) . $def; $def = $this->runBlockGamut($this->outdent($def . "\n\n")); $def = "\n" . $def . "\n"; } else { $def = rtrim($def); $def = $this->runSpanGamut($this->outdent($def)); } return "\n<dd>" . $def . "</dd>\n"; } protected function doFencedCodeBlocks($text) { $less_than_tab = $this->tab_width; $text = preg_replace_callback('{
    				(?:\n|\A)
    				# 1: Opening marker
    				(
    					(?:~{3,}|`{3,}) # 3 or more tildes/backticks.
    				)
    				[ ]*
    				(?:
    					\.?([-_:a-zA-Z0-9]+) # 2: standalone class name
    				|
    					' . $this->id_class_attr_catch_re . ' # 3: Extra attributes
    				)?
    				[ ]* \n # Whitespace and newline following marker.
    				
    				# 4: Content
    				(
    					(?>
    						(?!\1 [ ]* \n)	# Not a closing marker.
    						.*\n+
    					)+
    				)
    				
    				# Closing marker.
    				\1 [ ]* (?= \n )
    			}xm', array($this, '_doFencedCodeBlocks_callback'), $text); return $text; } protected function _doFencedCodeBlocks_callback($matches) { $classname =& $matches[2]; $attrs =& $matches[3]; $codeblock = $matches[4]; $codeblock = htmlspecialchars($codeblock, ENT_NOQUOTES); $codeblock = preg_replace_callback('/^\n+/', array($this, '_doFencedCodeBlocks_newlines'), $codeblock); if ($classname != "") { if ($classname{0} == '.') { $classname = substr($classname, 1); } $attr_str = ' class="' . $this->code_class_prefix . $classname . '"'; } else { $attr_str = $this->doExtraAttributes($this->code_attr_on_pre ? "pre" : "code", $attrs); } $pre_attr_str = $this->code_attr_on_pre ? $attr_str : ''; $code_attr_str = $this->code_attr_on_pre ? '' : $attr_str; $codeblock = "<pre$pre_attr_str><code$code_attr_str>$codeblock</code></pre>"; return "\n\n" . $this->hashBlock($codeblock) . "\n\n"; } protected function _doFencedCodeBlocks_newlines($matches) { return str_repeat("<br$this->empty_element_suffix", strlen($matches[0])); } protected $em_relist = array( '' => '(?:(?<!\*)\*(?!\*)|(?<![a-zA-Z0-9_])_(?!_))(?![\.,:;]?\s)', '*' => '(?<![\s*])\*(?!\*)', '_' => '(?<![\s_])_(?![a-zA-Z0-9_])', ); protected $strong_relist = array( '' => '(?:(?<!\*)\*\*(?!\*)|(?<![a-zA-Z0-9_])__(?!_))(?![\.,:;]?\s)', '**' => '(?<![\s*])\*\*(?!\*)', '__' => '(?<![\s_])__(?![a-zA-Z0-9_])', ); protected $em_strong_relist = array( '' => '(?:(?<!\*)\*\*\*(?!\*)|(?<![a-zA-Z0-9_])___(?!_))(?![\.,:;]?\s)', '***' => '(?<![\s*])\*\*\*(?!\*)', '___' => '(?<![\s_])___(?![a-zA-Z0-9_])', ); protected function formParagraphs($text) { $text = preg_replace('/\A\n+|\n+\z/', '', $text); $grafs = preg_split('/\n{2,}/', $text, -1, PREG_SPLIT_NO_EMPTY); foreach ($grafs as $key => $value) { $value = trim($this->runSpanGamut($value)); $is_p = !preg_match('/^B\x1A[0-9]+B|^C\x1A[0-9]+C$/', $value); if ($is_p) { $value = "<p>$value</p>"; } $grafs[$key] = $value; } $text = implode("\n\n", $grafs); $text = $this->unhash($text); return $text; } protected function stripFootnotes($text) { $less_than_tab = $this->tab_width - 1; $text = preg_replace_callback('{
    			^[ ]{0,' . $less_than_tab . '}\[\^(.+?)\][ ]?:	# note_id = $1
    			  [ ]*
    			  \n?					# maybe *one* newline
    			(						# text = $2 (no blank lines allowed)
    				(?:					
    					.+				# actual text
    				|
    					\n				# newlines but 
    					(?!\[.+?\][ ]?:\s)# negative lookahead for footnote or link definition marker.
    					(?!\n+[ ]{0,3}\S)# ensure line is not blank and followed 
    									# by non-indented content
    				)*
    			)		
    			}xm', array($this, '_stripFootnotes_callback'), $text); return $text; } protected function _stripFootnotes_callback($matches) { $note_id = $this->fn_id_prefix . $matches[1]; $this->footnotes[$note_id] = $this->outdent($matches[2]); return ''; } protected function doFootnotes($text) { if (!$this->in_anchor) { $text = preg_replace('{\[\^(.+?)\]}', "F\x1Afn:\\1\x1A:", $text); } return $text; } protected function appendFootnotes($text) { $text = preg_replace_callback('{F\x1Afn:(.*?)\x1A:}', array($this, '_appendFootnotes_callback'), $text); if (!empty($this->footnotes_ordered)) { $text .= "\n\n"; $text .= "<div class=\"footnotes\">\n"; $text .= "<hr" . $this->empty_element_suffix . "\n"; $text .= "<ol>\n\n"; $attr = ""; if ($this->fn_backlink_class != "") { $class = $this->fn_backlink_class; $class = $this->encodeAttribute($class); $attr .= " class=\"$class\""; } if ($this->fn_backlink_title != "") { $title = $this->fn_backlink_title; $title = $this->encodeAttribute($title); $attr .= " title=\"$title\""; } $num = 0; while (!empty($this->footnotes_ordered)) { $footnote = reset($this->footnotes_ordered); $note_id = key($this->footnotes_ordered); unset($this->footnotes_ordered[$note_id]); $ref_count = $this->footnotes_ref_count[$note_id]; unset($this->footnotes_ref_count[$note_id]); unset($this->footnotes[$note_id]); $footnote .= "\n"; $footnote = $this->runBlockGamut("$footnote\n"); $footnote = preg_replace_callback('{F\x1Afn:(.*?)\x1A:}', array($this, '_appendFootnotes_callback'), $footnote); $attr = str_replace("%%", ++$num, $attr); $note_id = $this->encodeAttribute($note_id); $backlink = "<a href=\"#fnref:$note_id\"$attr>&#8617;</a>"; for ($ref_num = 2; $ref_num <= $ref_count; ++$ref_num) { $backlink .= " <a href=\"#fnref$ref_num:$note_id\"$attr>&#8617;</a>"; } if (preg_match('{</p>$}', $footnote)) { $footnote = substr($footnote, 0, -4) . "&#160;$backlink</p>"; } else { $footnote .= "\n\n<p>$backlink</p>"; } $text .= "<li id=\"fn:$note_id\">\n"; $text .= $footnote . "\n"; $text .= "</li>\n\n"; } $text .= "</ol>\n"; $text .= "</div>"; } return $text; } protected function _appendFootnotes_callback($matches) { $node_id = $this->fn_id_prefix . $matches[1]; if (isset($this->footnotes[$node_id])) { $num =& $this->footnotes_numbers[$node_id]; if (!isset($num)) { $this->footnotes_ordered[$node_id] = $this->footnotes[$node_id]; $this->footnotes_ref_count[$node_id] = 1; $num = $this->footnote_counter++; $ref_count_mark = ''; } else { $ref_count_mark = $this->footnotes_ref_count[$node_id] += 1; } $attr = ""; if ($this->fn_link_class != "") { $class = $this->fn_link_class; $class = $this->encodeAttribute($class); $attr .= " class=\"$class\""; } if ($this->fn_link_title != "") { $title = $this->fn_link_title; $title = $this->encodeAttribute($title); $attr .= " title=\"$title\""; } $attr = str_replace("%%", $num, $attr); $node_id = $this->encodeAttribute($node_id); return "<sup id=\"fnref$ref_count_mark:$node_id\">" . "<a href=\"#fn:$node_id\"$attr>$num</a>" . "</sup>"; } return "[^" . $matches[1] . "]"; } protected function stripAbbreviations($text) { $less_than_tab = $this->tab_width - 1; $text = preg_replace_callback('{
    			^[ ]{0,' . $less_than_tab . '}\*\[(.+?)\][ ]?:	# abbr_id = $1
    			(.*)					# text = $2 (no blank lines allowed)	
    			}xm', array($this, '_stripAbbreviations_callback'), $text); return $text; } protected function _stripAbbreviations_callback($matches) { $abbr_word = $matches[1]; $abbr_desc = $matches[2]; if ($this->abbr_word_re) { $this->abbr_word_re .= '|'; } $this->abbr_word_re .= preg_quote($abbr_word); $this->abbr_desciptions[$abbr_word] = trim($abbr_desc); return ''; } protected function doAbbreviations($text) { if ($this->abbr_word_re) { $text = preg_replace_callback('{' . '(?<![\w\x1A])' . '(?:' . $this->abbr_word_re . ')' . '(?![\w\x1A])' . '}', array($this, '_doAbbreviations_callback'), $text); } return $text; } protected function _doAbbreviations_callback($matches) { $abbr = $matches[0]; if (isset($this->abbr_desciptions[$abbr])) { $desc = $this->abbr_desciptions[$abbr]; if (empty($desc)) { return $this->hashPart("<abbr>$abbr</abbr>"); } else { $desc = $this->encodeAttribute($desc); return $this->hashPart("<abbr title=\"$desc\">$abbr</abbr>"); } } else { return $matches[0]; } } } } namespace __auto_append { define("__CONTENT_DIR__", __DIR__ . '/_content'); $application = new \MicronCMS\Application(__CONTENT_DIR__); $application->setCache(true); $response = $application->dispatch(); $response->send(); } 