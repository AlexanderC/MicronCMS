${include _header.md}
${include widgets/_upload.html}
## It works!
#### For more details visit [GitHub project page](https://github.com/AlexanderC/MicronCMS "GitHub page")
${include _footer.md}